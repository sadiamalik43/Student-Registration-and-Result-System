import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.util.*;

public class CarRentalSystemGUI extends Application {
    private static final Map<String, String> customers = new HashMap<>();
    private static final List<Car> cars = new ArrayList<>();
    private static final List<Booking> bookings = new ArrayList<>();

    public static void main(String[] args) {
        loadCars();
        loadBookings();
        customers.put("user", "pass");
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Car Rental System");
        primaryStage.setScene(getLoginScene(primaryStage));
        primaryStage.setOnCloseRequest(e -> {
            saveCars();
            saveBookings();
        });
        primaryStage.show();
    }

    private Scene getLoginScene(Stage stage) {
        Label userLabel = new Label("Username:");
        TextField usernameField = new TextField();

        Label passLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        Button loginBtn = new Button("Login");
        Button signupBtn = new Button("Sign Up");

        VBox layout = new VBox(10, userLabel, usernameField, passLabel, passwordField, loginBtn, signupBtn);
        layout.setPadding(new Insets(20));

        loginBtn.setOnAction(e -> {
            String uname = usernameField.getText();
            String pwd = passwordField.getText();
            if (uname.equals("admin") && pwd.equals("admin123")) {
                stage.setScene(getAdminScene(stage));
            } else if (checkCustomerLogin(uname, pwd)) {
                stage.setScene(getCustomerScene(stage, uname));
            } else {
                showAlert("Login Failed", "Invalid credentials");
            }
        });

        signupBtn.setOnAction(e -> stage.setScene(getSignupScene(stage)));

        return new Scene(layout, 300, 250);
    }

    private Scene getSignupScene(Stage stage) {
        Label userLabel = new Label("Choose Username:");
        TextField usernameField = new TextField();
        Label passLabel = new Label("Choose Password:");
        PasswordField passwordField = new PasswordField();
        Button registerBtn = new Button("Register");

        VBox layout = new VBox(10, userLabel, usernameField, passLabel, passwordField, registerBtn);
        layout.setPadding(new Insets(20));

        registerBtn.setOnAction(e -> {
            String uname = usernameField.getText();
            String pwd = passwordField.getText();
            if (registerCustomer(uname, pwd)) {
                showAlert("Success", "Registration complete!");
                stage.setScene(getLoginScene(stage));
            } else {
                showAlert("Error", "Username already exists!");
            }
        });

        return new Scene(layout, 300, 250);
    }

    private Scene getAdminScene(Stage stage) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Button addBtn = new Button("Add Car");
        Button viewBtn = new Button("View Cars");
        Button viewBookingsBtn = new Button("View All Bookings");

        addBtn.setOnAction(e -> showAddCarDialog(stage));
        viewBtn.setOnAction(e -> stage.setScene(getViewCarsScene(stage)));
        viewBookingsBtn.setOnAction(e -> stage.setScene(getAllBookingsScene(stage)));

        layout.getChildren().addAll(new Label("Welcome, Admin!"), addBtn, viewBtn, viewBookingsBtn);
        return new Scene(layout, 300, 200);
    }

    private Scene getCustomerScene(Stage stage, String username) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Button viewCarsBtn = new Button("Book a Car");
        Button viewBookingsBtn = new Button("My Bookings");

        viewCarsBtn.setOnAction(e -> stage.setScene(getBookableCarsScene(stage, username)));
        viewBookingsBtn.setOnAction(e -> stage.setScene(getMyBookingsScene(stage, username)));

        layout.getChildren().addAll(new Label("Welcome, " + username + "!"), viewCarsBtn, viewBookingsBtn);
        return new Scene(layout, 300, 200);
    }

    private Scene getViewCarsScene(Stage stage) {
        TableView<Car> table = createCarTable(FXCollections.observableArrayList(cars));

        VBox layout = new VBox(table);
        layout.setPadding(new Insets(20));
        return new Scene(layout, 500, 350);
    }

    private Scene getBookableCarsScene(Stage stage, String username) {
        List<Car> availableCars = new ArrayList<>();
        for (Car car : cars) {
            if (!isCarBooked(car)) {
                availableCars.add(car);
            }
        }
        TableView<Car> table = createCarTable(FXCollections.observableArrayList(availableCars));

        Button bookBtn = new Button("Book Selected Car");
        bookBtn.setOnAction(e -> {
            Car selectedCar = table.getSelectionModel().getSelectedItem();
            if (selectedCar != null && !isCarBooked(selectedCar)) {
                bookings.add(new Booking(username, selectedCar));
                showAlert("Success", "Car booked successfully!");
                stage.setScene(getCustomerScene(stage, username));
            } else {
                showAlert("Error", "Car is already booked or not selected.");
            }
        });

        VBox layout = new VBox(10, table, bookBtn);
        layout.setPadding(new Insets(20));
        return new Scene(layout, 500, 400);
    }

    private Scene getMyBookingsScene(Stage stage, String username) {
        ListView<String> list = new ListView<>();
        for (Booking b : bookings) {
            if (b.getUsername().equals(username)) {
                list.getItems().add(b.toString());
            }
        }

        Button cancelBtn = new Button("Cancel Selected Booking");
        cancelBtn.setOnAction(e -> {
            String selected = list.getSelectionModel().getSelectedItem();
            if (selected != null) {
                bookings.removeIf(b -> b.toString().equals(selected));
                list.getItems().remove(selected);
                showAlert("Success", "Booking cancelled.");
            } else {
                showAlert("Error", "Please select a booking to cancel.");
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> stage.setScene(getCustomerScene(stage, username)));

        VBox layout = new VBox(10, new Label("My Bookings:"), list, cancelBtn, backBtn);
        layout.setPadding(new Insets(20));
        return new Scene(layout, 500, 400);
    }

    private Scene getAllBookingsScene(Stage stage) {
        ListView<String> list = new ListView<>();
        for (Booking b : bookings) {
            list.getItems().add(b.toString());
        }

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> stage.setScene(getAdminScene(stage)));

        VBox layout = new VBox(10, new Label("All Bookings:"), list, backBtn);
        layout.setPadding(new Insets(20));
        return new Scene(layout, 500, 400);
    }

    private TableView<Car> createCarTable(List<Car> carsList) {
        TableView<Car> table = new TableView<>();
        table.setItems(FXCollections.observableArrayList(carsList));

        TableColumn<Car, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().id));

        TableColumn<Car, String> brandCol = new TableColumn<>("Brand");
        brandCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().brand));

        TableColumn<Car, String> modelCol = new TableColumn<>("Model");
        modelCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().model));

        TableColumn<Car, String> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(data -> new SimpleStringProperty("$" + data.getValue().price));

        TableColumn<Car, String> catCol = new TableColumn<>("Category");
        catCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().category));

        table.getColumns().addAll(idCol, brandCol, modelCol, priceCol, catCol);
        return table;
    }

    private boolean checkCustomerLogin(String user, String pass) {
        return customers.containsKey(user) && customers.get(user).equals(pass);
    }

    private boolean registerCustomer(String user, String pass) {
        if (customers.containsKey(user)) return false;
        customers.put(user, pass);
        return true;
    }

    private boolean isCarBooked(Car car) {
        return bookings.stream().anyMatch(b -> b.car.id.equals(car.id));
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static void saveCars() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("cars.dat"))) {
            oos.writeObject(cars);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void loadCars() {
        File file = new File("cars.dat");
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                List<Car> loaded = (List<Car>) ois.readObject();
                cars.clear();
                cars.addAll(loaded);
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private static void saveBookings() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("bookings.dat"))) {
            oos.writeObject(bookings);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void loadBookings() {
        File file = new File("bookings.dat");
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                List<Booking> loaded = (List<Booking>) ois.readObject();
                bookings.clear();
                bookings.addAll(loaded);
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    static class Car implements Serializable {
        String id, brand, model, category;
        String price;

        public Car(String id, String brand, String model, String category, String price) {
            this.id = id;
            this.brand = brand;
            this.model = model;
            this.category = category;
            this.price = price;
        }
    }

    static class Booking implements Serializable {
        String username;
        Car car;

        public Booking(String username, Car car) {
            this.username = username;
            this.car = car;
        }

        public String getUsername() {
            return username;
        }

        public Car getCar() {
            return car;
        }

        @Override
        public String toString() {
            return username + " booked " + car.brand + " " + car.model + " ($" + car.price + ")";
        }
    }
} 

